import React, { useState, useEffect } from 'react';
import { getServers } from '../services/api';
import ServerCard from './ServerCard';

const Dashboard = () => {
  const [servers, setServers] = useState([]);

  useEffect(() => {
    // Fetch user servers from the backend API
    const fetchServers = async () => {
      const data = await getServers();
      setServers(data);
    };
    fetchServers();
  }, []);

  return (
    <div className="p-5">
      <h1 className="text-3xl mb-5">My Game Servers</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {servers.map((server) => (
          <ServerCard key={server.id} server={server} />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;