const ServerStatus = ({ status }) => {
  return (
    <div className={`py-2 px-4 rounded-full ${status === 'running' ? 'bg-green-500' : 'bg-red-500'}`}>
      {status === 'running' ? 'Running' : 'Stopped'}
    </div>
  );
};

export default ServerStatus;