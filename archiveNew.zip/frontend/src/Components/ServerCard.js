import React from 'react';
import ServerStatus from './ServerStatus';

const ServerCard = ({ server }) => {
  return (
    <div className="bg-gray-700 p-4 rounded-lg">
      <h2 className="text-xl">{server.name}</h2>
      <ServerStatus status={server.status} />
    </div>
  );
};

export default ServerCard;